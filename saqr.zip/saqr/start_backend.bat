@echo off
title Saqr Backend Server — Port 8000
echo ============================================================
echo  SAQR BACKEND — Starting FastAPI Engine on port 8000...
echo ============================================================
echo.

cd /d "%~dp0"

set PYTHONPATH=.
.venv\Scripts\uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload

echo.
echo Backend stopped. Press any key to exit...
pause > nul
